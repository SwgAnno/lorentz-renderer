#include "scenemaster.h"

SceneMaster::SceneMaster()
{
  //ctor
}

SceneMaster::~SceneMaster()
{
  //dtor
}

